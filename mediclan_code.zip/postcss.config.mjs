export default {
  plugins: {}
};
